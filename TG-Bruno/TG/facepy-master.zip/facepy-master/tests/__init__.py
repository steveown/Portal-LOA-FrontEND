"""
The ``tests`` module encapsulates Facepy's test suite::

    $ pip install -r requirements.txt
    $ make test

"""

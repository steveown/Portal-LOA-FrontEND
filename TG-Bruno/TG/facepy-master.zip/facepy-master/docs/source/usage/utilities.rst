.. _utilities:

Utilities
=========

.. autofunction:: facepy.utils.get_extended_access_token

.. autofunction:: facepy.utils.get_application_access_token
